'use client';

import React from 'react';
import { User } from '@/types';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  MapPin,
  Mail,
  Link as LinkIcon,
  Calendar,
  Edit,
  Share2,
  Shield,
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

interface ProfileHeaderProps {
  user: User;
  isOwnProfile?: boolean;
  onEdit?: () => void;
  onShare?: () => void;
}

export function ProfileHeader({
  user,
  isOwnProfile = false,
  onEdit,
  onShare,
}: ProfileHeaderProps) {
  return (
    <div className="bg-card rounded-lg shadow-sm p-6 md:p-8">
      <div className="flex flex-col md:flex-row gap-6">
        <Avatar
          src={user.avatar}
          alt={user.name}
          size="2xl"
          className="ring-4 ring-primary-100"
        />
        
        <div className="flex-1">
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <h1 className="text-2xl md:text-3xl font-bold">{user.name}</h1>
                {user.verification?.email && (
                  <Shield className="h-5 w-5 text-primary-600"/>
                )}
              </div>
              {user.bio && (
                <p className="text-muted-foreground text-sm md:text-base">{user.bio}</p>
              )}
            </div>
            
            {isOwnProfile ? (
              <Button onClick={onEdit} variant="outline" size="sm">
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button size="sm">Connect</Button>
                {onShare && (
                  <Button onClick={onShare} variant="outline" size="icon-sm">
                    <Share2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-4">
            {user.location && (
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                <span>{user.location}</span>
              </div>
            )}
            {user.email && isOwnProfile && (
              <div className="flex items-center gap-1">
                <Mail className="h-4 w-4" />
                <span>{user.email}</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              <span>Joined {format(new Date(user.createdAt), 'MMM yyyy')}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            <Badge variant="secondary">
              {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
            </Badge>
            <Badge variant="outline">
              Trust Score: {user.trustScore}
            </Badge>
          </div>

          {user.socialLinks && (
            <div className="flex gap-3">
              {user.socialLinks.linkedin && (
                <Link
                  href={user.socialLinks.linkedin}
                  target="_blank"
                  className="text-muted-foreground hover:text-primary-600"
                >
                  <LinkIcon className="h-5 w-5" />
                </Link>
              )}
              {user.socialLinks.github && (
                <Link
                  href={user.socialLinks.github}
                  target="_blank"
                  className="text-muted-foreground hover:text-primary-600"
                >
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
                  </svg>
                </Link>
              )}
              {user.socialLinks.portfolio && (
                <Link
                  href={user.socialLinks.portfolio}
                  target="_blank"
                  className="text-muted-foreground hover:text-primary-600"
                >
                  <LinkIcon className="h-5 w-5" />
                </Link>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}